#pragma once

#include <string>

namespace aasdk
{

class Version
{
public:
    // Semantic version components (YYYY.MM.DD format)
    static constexpr unsigned int MAJOR = 2025;
    static constexpr unsigned int MINOR = 11;  
    static constexpr unsigned int PATCH = 13;
    
    // Full version string with git info
    static constexpr const char* STRING = "2025.11.13";
    
    // Git information
    static constexpr const char* GIT_COMMIT = "unknown";
    static constexpr const char* GIT_BRANCH = "unknown";
    static constexpr const char* GIT_DESCRIBE = "unknown";
    static constexpr bool GIT_DIRTY = 0 > 0;
    
    // Build information
    static constexpr const char* BUILD_TYPE = "Release";
    static constexpr const char* BUILD_TIMESTAMP = __DATE__ " " __TIME__;
    
    // Helper methods
    static constexpr bool isDirty() { return GIT_DIRTY; }
    static constexpr bool isDebug() { 
#ifdef DEBUG
        return true;
#else
        return false;
#endif
    }
    
    // Get version as string in format "MAJOR.MINOR.PATCH"
    static std::string getSemanticVersion() {
        return std::to_string(MAJOR) + "." + 
               std::to_string(MINOR) + "." + 
               std::to_string(PATCH);
    }
    
    // Get full version string
    static const char* getFullVersion() { return STRING; }
    
    // Get git commit ID
    static const char* getGitCommit() { return GIT_COMMIT; }
    
    // Get git branch
    static const char* getGitBranch() { return GIT_BRANCH; }
    
    // Check if built from clean repository
    static bool isCleanBuild() { return !GIT_DIRTY; }
};

}
