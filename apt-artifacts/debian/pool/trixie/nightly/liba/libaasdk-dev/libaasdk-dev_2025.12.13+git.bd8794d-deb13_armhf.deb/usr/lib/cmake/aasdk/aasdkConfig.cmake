set(AASDK_INCLUDE_DIRS /usr/include)
set(AASDK_LIB_DIRS /usr/lib/arm-linux-gnueabihf)
include("${CMAKE_CURRENT_LIST_DIR}/aasdkTargets.cmake")
