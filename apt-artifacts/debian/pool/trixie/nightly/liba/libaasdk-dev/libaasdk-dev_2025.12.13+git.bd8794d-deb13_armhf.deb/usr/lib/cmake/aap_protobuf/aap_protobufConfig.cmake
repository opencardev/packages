set(AAP_PROTOBUF_INCLUDE_DIRS /usr/include)
set(AAP_PROTOBUF_LIB_DIRS /usr/lib/arm-linux-gnueabihf)
include("${CMAKE_CURRENT_LIST_DIR}/aap_protobufTargets.cmake")
