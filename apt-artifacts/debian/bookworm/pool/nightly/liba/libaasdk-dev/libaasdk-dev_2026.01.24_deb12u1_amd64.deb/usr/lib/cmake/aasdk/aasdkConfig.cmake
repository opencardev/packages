set(AASDK_INCLUDE_DIRS )
set(AASDK_LIB_DIRS )
include("${CMAKE_CURRENT_LIST_DIR}/aasdkTargets.cmake")
