#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "AAPProto::aap_protobuf" for configuration "Release"
set_property(TARGET AAPProto::aap_protobuf APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(AAPProto::aap_protobuf PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libaap_protobuf.so.2026.02.+"
  IMPORTED_SONAME_RELEASE "libaap_protobuf.so.2026"
  )

list(APPEND _cmake_import_check_targets AAPProto::aap_protobuf )
list(APPEND _cmake_import_check_files_for_AAPProto::aap_protobuf "${_IMPORT_PREFIX}/lib/libaap_protobuf.so.2026.02.+" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
