set(AASDK_INCLUDE_DIRS /usr/include)
set(AASDK_LIB_DIRS /usr/lib/x86_64-linux-gnu)
include("${CMAKE_CURRENT_LIST_DIR}/aasdkTargets.cmake")
