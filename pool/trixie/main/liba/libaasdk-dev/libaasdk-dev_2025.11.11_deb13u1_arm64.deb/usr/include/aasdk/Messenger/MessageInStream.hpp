// This file is part of aasdk library project.
// Copyright (C) 2018 f1x.studio (Michal Szwaj)
// Copyright (C) 2024 CubeOne (Simon Dean - simon.dean@cubeone.co.uk)
//
// aasdk is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 3 of the License, or
// (at your option) any later version.
//
// aasdk is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with aasdk. If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <map>
#include <aasdk/Transport/ITransport.hpp>
#include <aasdk/Messenger/IMessageInStream.hpp>
#include <aasdk/Messenger/ICryptor.hpp>
#include <aasdk/Messenger/FrameHeader.hpp>
#include <aasdk/Messenger/FrameSize.hpp>
#include <aasdk/Messenger/FrameType.hpp>


namespace aasdk {
  namespace messenger {

    class MessageInStream
        : public IMessageInStream, public std::enable_shared_from_this<MessageInStream>, boost::noncopyable {
    public:
      MessageInStream(boost::asio::io_service &ioService, transport::ITransport::Pointer transport,
                      ICryptor::Pointer cryptor);

      void startReceive(ReceivePromise::Pointer promise) override;

    private:
      using std::enable_shared_from_this<MessageInStream>::shared_from_this;

      void receiveFrameHeaderHandler(const common::DataConstBuffer &buffer);

      void receiveFrameSizeHandler(const common::DataConstBuffer &buffer);

      void receiveFramePayloadHandler(const common::DataConstBuffer &buffer);

      boost::asio::io_service::strand strand_;
      transport::ITransport::Pointer transport_;
      ICryptor::Pointer cryptor_;

      FrameType thisFrameType_;
      ReceivePromise::Pointer promise_;
      ReceivePromise::Pointer interleavedPromise_;
      Message::Pointer message_;

      std::map<messenger::ChannelId, Message::Pointer> messageBuffer_;

      int frameSize_;
      bool isValidFrame_;
    };

  }
}
