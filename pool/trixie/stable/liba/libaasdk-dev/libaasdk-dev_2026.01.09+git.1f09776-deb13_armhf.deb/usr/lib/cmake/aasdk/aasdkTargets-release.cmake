#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "AASDK::aasdk" for configuration "Release"
set_property(TARGET AASDK::aasdk APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(AASDK::aasdk PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libaasdk.so.2026.01.09"
  IMPORTED_SONAME_RELEASE "libaasdk.so.2026"
  )

list(APPEND _cmake_import_check_targets AASDK::aasdk )
list(APPEND _cmake_import_check_files_for_AASDK::aasdk "${_IMPORT_PREFIX}/lib/libaasdk.so.2026.01.09" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
